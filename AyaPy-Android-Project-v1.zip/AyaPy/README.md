# AyaPy

AyaPy is an Android Python IDE starter project with a Liquid Glass-inspired interface and an embedded CPython 3.13 runtime using Chaquopy.

## Build from an Android phone (free)

1. Download and extract this project ZIP.
2. Create a GitHub account or sign in at https://github.com.
3. Create a new **public or private** repository named `AyaPy`.
4. Upload the extracted project files and folders to the repository root. Keep the `.github/workflows/build-apk.yml` path intact.
5. Open the repository's **Actions** tab and enable Actions if GitHub asks.
6. Run **Build AyaPy APK** using **Run workflow**, or push a commit to `main`.
7. Open the completed workflow run, scroll to **Artifacts**, and download `AyaPy-debug-apk`.
8. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser or file manager.

## What is included

- Liquid Glass-inspired Compose home screen.
- Embedded Python 3.13 runtime (arm64-v8a).
- Python code editor and run action.
- Captured stdout, stderr and Python tracebacks.
- Terminal output screen.
- Sample scripts.
- Package build configuration.

## Add Python packages

Packages are currently bundled into the APK at build time. In `app/build.gradle.kts`, add packages inside the `chaquopy { defaultConfig { pip { ... } } }` block:

```kotlin
chaquopy {
    defaultConfig {
        version = "3.13"
        pip {
            install("requests")
            install("beautifulsoup4")
        }
    }
}
```

Then commit and rebuild. Native packages must have wheels compatible with Chaquopy's Android runtime. A normal desktop pip install is not guaranteed to work on Android.

## Current MVP limitations

- Interactive `input()` is not wired to a terminal input queue yet.
- Pip package installation is build-time, not dynamically installed inside the app.
- File picker / persistent project workspace is not implemented yet.
- This is a debug APK starter; release signing and production hardening are future steps.

## Technical stack

- Kotlin + Jetpack Compose
- Chaquopy 17.2.0
- CPython 3.13
- Android Gradle Plugin 8.13.2
- Gradle 8.13
