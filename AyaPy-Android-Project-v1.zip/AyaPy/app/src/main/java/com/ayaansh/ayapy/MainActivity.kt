package com.ayaansh.ayapy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF080B16)
private val Glass = Color(0xB8202B49)
private val Edge = Color(0x557D91C7)
private val White = Color(0xFFF3F5FF)
private val Muted = Color(0xFFAAB5D0)
private val Blue = Color(0xFF91B5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        setContent { AyaPyApp() }
    }
}

private enum class Screen { HOME, EDITOR, TERMINAL, SETTINGS, SAMPLES, PIP }

@Composable
fun AyaPyApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var code by remember { mutableStateOf("print('Hello from AyaPy!')\nprint('Python is running on Android.')") }
    var output by remember { mutableStateOf("AyaPy terminal ready.\n") }
    var running by remember { mutableStateOf(false) }

    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF080B16), Color(0xFF17264A), Color(0xFF160F2A)))
        )
    ) {
        Box(Modifier.size(240.dp).offset(x = 190.dp, y = 90.dp).blur(90.dp).background(Color(0x553B68C8), CircleShape))
        Box(Modifier.size(220.dp).align(Alignment.BottomStart).offset(x = (-70).dp, y = 60.dp).blur(90.dp).background(Color(0x554E3C91), CircleShape))
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            TopBar(onHome = { screen = Screen.HOME })
            Spacer(Modifier.height(14.dp))
            when (screen) {
                Screen.HOME -> HomeScreen(
                    onOpen = { screen = it },
                    onRun = {
                        screen = Screen.EDITOR
                        running = true
                    }
                )
                Screen.EDITOR -> EditorScreen(
                    code = code, onCode = { code = it }, output = output,
                    running = running,
                    onRun = {
                        running = true
                        output = "Running main.py…\n"
                    },
                    onStop = { running = false; output += "\n[Stopped by user]\n" },
                    onTerminal = { screen = Screen.TERMINAL }
                )
                Screen.TERMINAL -> TerminalScreen(output = output, onBack = { screen = Screen.EDITOR })
                Screen.SETTINGS -> InfoScreen("Settings", "AyaPy v1.0\nPython 3.13 runtime\nLiquid Glass interface\n\nMore editor and runtime settings are coming in the next release.")
                Screen.SAMPLES -> SamplesScreen(onSelect = { code = it; screen = Screen.EDITOR })
                Screen.PIP -> InfoScreen("Python packages", "Packages are currently bundled at build time.\n\nTo add a package, open app/build.gradle.kts and add it inside the Chaquopy pip block, then rebuild the APK.\n\nExample: install(\\\"requests\\\")")
            }
            Spacer(Modifier.height(8.dp))
            Text("AYA PYTHON ENVIRONMENT", color = Muted.copy(alpha = .65f), fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }

    LaunchedEffect(running, code) {
        if (running) {
            val result = withContext(Dispatchers.IO) {
                try {
                    Python.getInstance().getModule("runner").callAttr("execute", code).toString()
                } catch (e: Exception) {
                    "Runtime error: ${e.message}"
                }
            }
            output = result
            running = false
        }
    }
}

@Composable
private fun TopBar(onHome: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.clickable { onHome() }) {
            Text("AyaPy", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Python IDE for Android", color = Muted, fontSize = 12.sp)
        }
        Surface(color = Color(0x553D6B58), shape = RoundedCornerShape(50), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x6659C58A))) {
            Text("●  READY", color = Color(0xFF9DE4B5), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
        }
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(25.dp))
            .background(Glass)
            .border(1.dp, Edge, RoundedCornerShape(25.dp))
            .then(modifier)
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, modifier = Modifier.padding(start = 7.dp, top = 17.dp, bottom = 9.dp))
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Color(0x302C3856)).border(1.dp, Color(0x337C8CB2), RoundedCornerShape(20.dp))
            .clickable { onClick() }.padding(15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x557C8FB8)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color(0xFFD5E0FF))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun HomeScreen(onOpen: (Screen) -> Unit, onRun: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("main.py", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Line: 1/2\nLine offset: 0", color = Muted, lineHeight = 22.sp)
            Spacer(Modifier.height(12.dp))
            Text("PYTHON 3.13  ·  ARM64", color = Blue, fontSize = 10.sp, letterSpacing = 1.5.sp)
        }
        Spacer(Modifier.height(12.dp))
        MenuRow(Icons.Default.PlayCircle, "Interpreter", "Write and run Python code", onRun)
        Spacer(Modifier.height(9.dp))
        MenuRow(Icons.Default.Terminal, "Terminal", "View execution output", { onOpen(Screen.TERMINAL) })
        SectionLabel("TOOLS")
        MenuRow(Icons.Default.Layers, "Pip packages", "Package setup and build instructions", { onOpen(Screen.PIP) })
        Spacer(Modifier.height(9.dp))
        MenuRow(Icons.Default.Code, "Code samples", "Try a few Python examples", { onOpen(Screen.SAMPLES) })
        Spacer(Modifier.height(9.dp))
        MenuRow(Icons.Default.Share, "Share", "Sharing will be added in a later build", { })
        SectionLabel("SETTINGS")
        MenuRow(Icons.Default.Settings, "Settings", "App and runtime information", { onOpen(Screen.SETTINGS) })
    }
}

@Composable
private fun EditorScreen(
    code: String, onCode: (String) -> Unit, output: String, running: Boolean,
    onRun: () -> Unit, onStop: () -> Unit, onTerminal: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("main.py", color = White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallAction("Terminal", onTerminal)
                SmallAction(if (running) "Stop" else "▶ Run", if (running) onStop else onRun)
            }
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.weight(1f).fillMaxWidth()) {
            BasicTextField(
                value = code, onValueChange = onCode,
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                textStyle = TextStyle(color = Color(0xFFE2E9FF), fontSize = 14.sp, lineHeight = 22.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(Blue),
                decorationBox = { inner -> Box { if (code.isEmpty()) Text("Write Python here…", color = Muted); inner() } }
            )
        }
        SectionLabel("OUTPUT")
        GlassCard(Modifier.fillMaxWidth().heightIn(min = 110.dp, max = 190.dp)) {
            Text(output, color = Color(0xFFB8E9C7), fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun SmallAction(label: String, onClick: () -> Unit) {
    Surface(color = Color(0x553B568B), shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Edge)) {
        Text(label, color = White, fontSize = 12.sp, modifier = Modifier.clickable { onClick() }.padding(horizontal = 12.dp, vertical = 9.dp))
    }
}

@Composable
private fun TerminalScreen(output: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Terminal", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            SmallAction("Editor", onBack)
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxSize()) {
            Text("$ python main.py", color = Blue, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Text(output, color = Color(0xFFB8E9C7), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun SamplesScreen(onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Code samples", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        MenuRow(Icons.Default.Code, "Hello world", "Basic output", { onSelect("print('Hello, Ayaansh!')") })
        Spacer(Modifier.height(9.dp))
        MenuRow(Icons.Default.Calculate, "Calculator", "Simple arithmetic", { onSelect("a = 25\nb = 17\nprint('Sum:', a + b)\nprint('Product:', a * b)") })
        Spacer(Modifier.height(9.dp))
        MenuRow(Icons.Default.Loop, "Loops", "A simple for loop", { onSelect("for i in range(1, 6):\n    print('Count:', i)") })
    }
}

@Composable
private fun InfoScreen(title: String, body: String) {
    GlassCard(Modifier.fillMaxWidth()) {
        Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(body, color = Muted, fontSize = 14.sp, lineHeight = 23.sp)
    }
}
