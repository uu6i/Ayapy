import contextlib
import io
import traceback

def execute(source: str) -> str:
    output = io.StringIO()
    namespace = {"__name__": "__main__", "__file__": "main.py"}
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(compile(source, "main.py", "exec"), namespace, namespace)
    except SystemExit as exc:
        output.write(f"\nProgram exited: {exc}\n")
    except Exception:
        traceback.print_exc(file=output)
    result = output.getvalue()
    return result if result else "(Program finished with no output.)"
